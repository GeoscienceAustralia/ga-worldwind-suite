/**
 * Copyright (c) 2008-2010 Ardor Labs, Inc.
 *
 * This file is part of Ardor3D.
 *
 * Ardor3D is free software: you can redistribute it and/or modify it 
 * under the terms of its license which may be found in the accompanying
 * LICENSE file or at <http://www.ardor3d.com/LICENSE>.
 */

package com.ardor3d.util.export.binary;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import com.ardor3d.scenegraph.Spatial;
import com.ardor3d.util.export.Savable;

/**
 * Simple utility class that uses BinaryImporter/Exporter in memory to clone a spatial.
 */
public class BinaryCloner {
    public Spatial copy(final Spatial source) {
        try {
            final ByteArrayOutputStream bos = new ByteArrayOutputStream();
            final BinaryExporter exporter = new BinaryExporter();
            exporter.save(source, bos);
            bos.flush();
            final ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());
            final BinaryImporter importer = new BinaryImporter();
            final Savable sav = importer.load(bis);
            return (Spatial) sav;
        } catch (final IOException ex) {
            // should not happen, since we are dealing with only byte array streams.
            throw new RuntimeException(ex);
        }
    }

}
